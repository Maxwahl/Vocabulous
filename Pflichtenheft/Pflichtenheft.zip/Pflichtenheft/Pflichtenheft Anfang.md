# Pflichtenheft

##### Aufgaben, die im Pflichtenheft erledigt werden sollen
 * **Ordnerstruktur anlegen**
 * **Ausgangssituation**
 * **Ist-Zustand**
 * **Problemstellungen**
 * **Soll-Zustand/Soll-Aufgaben**
 * **Ziele**
 * **Funktionale Anforderungen (GUI)**
 * **Nicht-funktionale Anforderungen**
   
| Projektbezeichnung | Vocabolous 	 		|
|------------------- |:-------------------: |
| Projektleiter		 | Urbanides Konstantin |
| Erstellt am 		 | 19.11.2017		    |
| Zuletzt geändert	 | ------------			|
| Zustand			 | in Bearbeitung		|
| Dokumentenablage	 | ---------------		|


## Weitere Produktinformationen
| Mitwirkende |  	 		|
|------------ |:----------: |
| Erzeugung	  |             |

## Änderungsverzeichnis
|          Änderung | Geänderte Kapitel | Beschreibung der Änderung|     Autor     |
|------------------------------- |:----------------: | :------------------------:|:-------------:|
| Nr.	  |             |

## Inhalt

##### 1 Motivation 
##### 2	Ausgangssituation und Zielsetzung
###### 2.1 Ausgangssituation
---
###### 2.1.1 Beschreibung des Problembereiches
###### 2.1.2 Glossar
###### 2.1.3 Modell des Problembereiches
###### 2.1.4 Bechreibung des Geschäftsfeldes
###### 2.1.5 Beschreibung der Geschäftsprozesse
###### 2.2 Zielbestimmung
---
##### 3 Funktionale Anforderungen
###### 3.1 Use Case Diagramm
---
##### 4 Nicht-funktionale Anforderungen
##### 5 Mengengerüst
##### 6 Risikoakzeptanz
##### 7 Lebenszyklusanalyse und Gesamtsystemarchitektur
##### 8 Schnittstellenübersicht
##### 9 Lieferumfang
##### 10 Abnahmekriterien
##### 11 Anderungsverfolgung zu den Anfordernungen (Lastenheft)
##### 12 Abkürzungsverzeichnis
##### 13 Literaturverzeichnis
##### 14 Abbildungsverzeichnis




## 1 Motivation
Wir sehen dieses Projekt als Vorbereitung für zukunftige Projekte, um die Aufgaben und den Ablauf eines Projektes kennen zu lernen, sowie auch die verschiedenen Problembereiche eines Projektes zu identifizieren und diese auch vorbeugend zu behandeln. Projekte/Aufgaben in Gruppen zu erledigen ist in der IT-Branche sehr wichtig, da heutzutage viele Projekte vorallem in der IT-Branche in Gruppen erledigt werden, deshalb sehen wir dieses Projekt als Chance die gelernte Theorie in die Praxis umzusetzen und unsere Fähigkeiten in der Projektentwicklung zu verbessern.

## 2 Ausgangssituation und Zielsetzung
## 2.1 Ausgangssituation und Projektbegründung
---
In den vergangenen Jahren gingen beim Sprachlerninsitut Language4everyone Linz immer wieder Fragen auf Grund eines mobilen Assistenzprogrammes ein, um auch Vokabeln nicht nur mit Hilfe von PC zu überprüfen. 

Das Sprachlerninstitut hat somit um eine Entwicklung/Erstellung eines Vokabelüberprüfungsprogrammes angeordnet. Es soll ein Programm entwickelt werden, dass nicht nur auf PC sondern sowohl auch auf Smartphones einsatzbar ist, um auch zu Zeiten wo kein Computer zur Verfügung steht, Vokabeln lernen zu können. Das Vokabelprüfprogramm dient als Ergänzung zum Präsenzunterricht in den Kursräumlichkeiten des Language4everyone Instituts.

### 2.1.1 Beschreibung des Problembereiches
Das benötigte Vokabelüberprüfungsprogramm soll die Studenten, Schüler und Kunden des Sprachlerninsitutes Language4everyone Linz unterstützen und den Lernprozess digitalisieren, um nicht von einen PC abhängig zu sein, die Vokablen zu lernen.

### 2.1.2 Glossar


### 2.1.3 Modell des Problembereiches


### 2.1.4 Beschreibung des Geschäftsfeldes


### 2.1.5 Beschreibung der Geschäftsprozesse


## 3 Funktionale Anforderungen


## 3.1 Use Case Diagramm
---

## Charakterisierende Informationen


## GUI für den Aufruf des Use Cases


## Szenario für den Standardablauf (Erfolg)


## GUI für den Standardablauf des Use Cases


## Szenarien für alternative Abläufe (Misserfolg oder Umwege zum Erfolg)


## GUIs für  den alternative Abläufe des Use Cases


## Beschreibung des allgemeinen Ablaufes


## Offene Punkte


## 4 Nicht-funktionale Anforderungen


## 5 Mengengerüst


## 6 Risikoakzeptanz


## 7 Lebenszyklusanalyse und Gesamtsystemarchitektur


## 8 Schnittstellenübersicht


## 9 Lieferumfang


## 10 Abnahmekriterien


## 11 Anforderungsverfolgung zu den Anforderungen (Lastenheft)


## 12 Abkürzungsverzeichnis


## 13 Literaturverzeichnis

## 14 Abbildungsverzeichnis